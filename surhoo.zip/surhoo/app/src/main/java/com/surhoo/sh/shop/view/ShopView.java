package com.surhoo.sh.shop.view;

import com.surhoo.sh.base.BaseView;
import com.surhoo.sh.base.NoPageBaseView;
import com.surhoo.sh.base.NoPageListBaseView;
import com.surhoo.sh.shop.ShopDetailBean;

public interface ShopView extends NoPageBaseView<ShopDetailBean> {
}
