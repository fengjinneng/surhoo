package com.surhoo.sh.common.util;

public class EventBusBean {


    public static class Scenrio{

        public static final int ISHAVEGOODS = 1001;
        public static final int ISHAVEMETERIAL = 1002;

    }
}
