package com.surhoo.sh.collect;

import com.surhoo.sh.base.BasePresenter;

public interface CollectPresenter extends BasePresenter<CollectView> {
}
