package com.surhoo.sh.scenario.view;

import com.surhoo.sh.base.NoPageBaseView;
import com.surhoo.sh.base.PagerBaseView;
import com.surhoo.sh.scenario.bean.ScenarioBean;

import java.util.List;

public interface IScenarioView extends NoPageBaseView<ScenarioBean> {



}
