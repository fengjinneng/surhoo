package com.surhoo.sh.base;

public interface BaseView {

    void showToastMsg(String msg);

}
