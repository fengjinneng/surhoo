package com.surhoo.sh.goods.view.impl;

public interface OnDDD {

    void onddd(int position,String name);
}
