package com.surhoo.sh.login.view;

import com.surhoo.sh.base.BaseView;

public interface LoginView extends BaseView {


    void setCountDown(String text);

    void setSendVerifycodeEnable(boolean b);

}
