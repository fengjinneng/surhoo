package com.surhoo.sh.designer.bean;

public class FinishProductBean {

    /**
     * id : 1
     * userId : 10010085
     * works : http://yaochengkun-shanghu.f.wmeimob.com/9Y9V98R49BLN26Q99K669JL598433RM9.png
     * gmtCreate : 2019-08-15 07:16:08
     */

    private Integer id;
    private Integer userId;
    private String works;
    private String gmtCreate;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getWorks() {
        return works;
    }

    public void setWorks(String works) {
        this.works = works;
    }

    public String getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(String gmtCreate) {
        this.gmtCreate = gmtCreate;
    }
}
