package com.surhoo.sh.invoice.view;

import com.surhoo.sh.base.NoPageBaseView;

public interface EditInvoiceView {

    void getResult();

}
