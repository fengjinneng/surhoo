package com.surhoo.sh.collect;

import com.surhoo.sh.base.BaseView;

public interface CollectView extends BaseView {
}
