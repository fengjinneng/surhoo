package com.surhoo.sh.home.view;

import com.surhoo.sh.base.NoPageBaseView;
import com.surhoo.sh.home.bean.HomePageBean;

public interface HomeView extends NoPageBaseView<HomePageBean> {
}
