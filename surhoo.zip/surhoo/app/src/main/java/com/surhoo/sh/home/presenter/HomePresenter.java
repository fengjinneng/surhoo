package com.surhoo.sh.home.presenter;

import com.surhoo.sh.base.BasePresenter;
import com.surhoo.sh.home.view.HomeView;

public interface HomePresenter extends BasePresenter<HomeView> {

    void requestData();


}
