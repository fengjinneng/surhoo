package com.surhoo.sh.base;

public interface NoPageBaseView<T> extends BaseView{

    void showData(T t);

}
