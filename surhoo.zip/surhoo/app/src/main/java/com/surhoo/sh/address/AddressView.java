package com.surhoo.sh.address;

import com.surhoo.sh.base.NoPageBaseView;
import com.surhoo.sh.base.NoPageListBaseView;

public interface AddressView extends NoPageListBaseView<AddressBean>,NoPageBaseView<AddressBean> {
}
