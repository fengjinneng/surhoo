package com.surhoo.sh.designer.view;

import com.surhoo.sh.base.NoPageBaseView;
import com.surhoo.sh.designer.bean.DesignerDetailBean;

public interface DesignerViewList extends NoPageBaseView<DesignerDetailBean> {



}
