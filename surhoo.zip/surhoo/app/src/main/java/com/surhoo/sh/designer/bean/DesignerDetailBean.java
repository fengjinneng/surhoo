package com.surhoo.sh.designer.bean;

public class DesignerDetailBean {


    /**
     * id : 1
     * userId : 10010085
     * sysId : 48
     * level : 10
     * img : http://yaochengkun-shanghu.f.wmeimob.com/9Y9V98R49BLN26Q99K669JL598433RM9.png
     * video : http://yaochengkun-shanghu.f.wmeimob.com/K2RYN742VQ5H232U934Y58KM29SWNQ37.mp4
     * detail : 笑一笑
     * labelIds : #19#,#8#
     * labelNames : 闪亮,(♥∀♥)
     * nickname : 哈哈哈
     * gmtCreate : 2019-08-09 10:25:01
     * gmtModified : 2019-08-15 03:25:42
     * works : http://yaochengkun-shanghu.f.wmeimob.com/9Y9V98R49BLN26Q99K669JL598433RM9.png,http://yaochengkun-shanghu.f.wmeimob.com/9Y9V98R49BLN26Q99K669JL598433RM9.png
     * status : 1
     * headimgurl : https://wx.qlogo.cn/mmopen/vi_32/tw1LOSJbOXzhXO8DS9icj6AuxQESDjHlYMn8vIhlC4iasD3kNySE2bS6UF99OaMltBVvGDxr6ziam18hWtC96F5tg/132
     * labelIdList : null
     * isCollect : false
     */

    private Integer id;
    private Integer userId;
    private Integer sysId;
    private Integer level;
    private String img;
    private String video;
    private String detail;
    private String labelIds;
    private String labelNames;
    private String nickname;
    private String gmtCreate;
    private String gmtModified;
    private String works;
    private Integer status;
    private String headimgurl;
    private Object labelIdList;
    private Boolean isCollect;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getSysId() {
        return sysId;
    }

    public void setSysId(Integer sysId) {
        this.sysId = sysId;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getLabelIds() {
        return labelIds;
    }

    public void setLabelIds(String labelIds) {
        this.labelIds = labelIds;
    }

    public String getLabelNames() {
        return labelNames;
    }

    public void setLabelNames(String labelNames) {
        this.labelNames = labelNames;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(String gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public String getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(String gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getWorks() {
        return works;
    }

    public void setWorks(String works) {
        this.works = works;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getHeadimgurl() {
        return headimgurl;
    }

    public void setHeadimgurl(String headimgurl) {
        this.headimgurl = headimgurl;
    }

    public Object getLabelIdList() {
        return labelIdList;
    }

    public void setLabelIdList(Object labelIdList) {
        this.labelIdList = labelIdList;
    }

    public Boolean getCollect() {
        return isCollect;
    }

    public void setCollect(Boolean collect) {
        isCollect = collect;
    }
}
