package com.surhoo.sh.goods.view;

import com.surhoo.sh.base.NoPageListBaseView;
import com.surhoo.sh.goods.bean.CategoryBean;

import java.util.List;

public interface CategoryListView extends NoPageListBaseView<CategoryBean> {


}
