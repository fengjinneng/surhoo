package com.surhoo.sh.invoice.view;

import com.surhoo.sh.base.NoPageListBaseView;
import com.surhoo.sh.invoice.bean.InvoiceBean;

public interface InvoiceView extends NoPageListBaseView<InvoiceBean> {
}
