package com.surhoo.sh.material.view;

import com.surhoo.sh.base.NoPageBaseView;
import com.surhoo.sh.material.bean.MaterialBean;

public interface MaterialDetailView extends NoPageBaseView<MaterialBean> {
}
