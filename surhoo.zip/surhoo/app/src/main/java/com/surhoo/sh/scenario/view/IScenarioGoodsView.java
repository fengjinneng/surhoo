package com.surhoo.sh.scenario.view;

import com.surhoo.sh.base.PagerBaseView;

public interface IScenarioGoodsView extends PagerBaseView {
}
