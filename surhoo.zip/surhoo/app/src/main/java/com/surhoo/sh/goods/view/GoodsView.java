package com.surhoo.sh.goods.view;

import com.surhoo.sh.base.PagerBaseView;

public interface GoodsView extends PagerBaseView {

}
