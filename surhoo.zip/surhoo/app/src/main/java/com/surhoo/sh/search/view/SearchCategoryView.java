package com.surhoo.sh.search.view;

import com.surhoo.sh.base.NoPageListBaseView;
import com.surhoo.sh.base.PagerBaseView;

import java.util.List;


public interface SearchCategoryView extends PagerBaseView,NoPageListBaseView {


}
